sap.ui.define([
	"sap/ui/core/mvc/Controller"
],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
	function (Controller) {
		"use strict";

		return Controller.extend("vital.prices.controller.Main", {
			onInit: function () {
			
			},

			onPress: function(oEvent) {

				this.getView().setModel( new sap.ui.model.json.JSONModel( oEvent.getSource().getBindingContext().getObject() ), "object" );
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("Detail", {
					id: oEvent.getSource().getBindingContext().getObject().PriceId
				});
			},

			//---------------------------------------------------------//
			/* Handle Upload de Files								   */
			onFileChange: function(oEvent) {
			
				var aFiles = jQuery.sap.domById(oEvent.getSource().getId() + "-fu").files;
			
				if (aFiles[0] && oEvent.getSource().getValue()) {
					this.oContentUpload = aFiles[0];
				} else {
					this.oContentUpload = null;
				}
			
			},

			onUpload: function (oEvent) {
				this.getView().byId("CERT_UPLOADER").upload();
			},

			handleUploadComplete: function(oEvent) {
			
				var that = this;
				
				if (!this.oContentUpload.oReader) { 
					this.oContentUpload.oReader = new FileReader();
				}
				
				this.oContentUpload.oReader.onloadend = (function(oFile) { 
					return function(oAnexo) { 
						if(oAnexo) {
							var base64_marker = 'data:' + oFile.type + ';base64'; 
							var base64 = oAnexo.target.result.split(base64_marker + ',')[1];
							
							var oEntry = {
								Value: base64,
								Mimetype: oFile.type
							};
							
							// El SLUG debería ir como JSON pero el back lo parsea como string
							/* var oHeader = {
								IDEAL:"01",
								PriceId: "00505681-B634-1EEB-BFA4-0E9DDEB93833",
								STORE: "T000",
								ACTDATE: "20.08.2021"
							};
							
							var vSlug = JSON.stringify(oHeader); */

							var vSlug = "IDEAL=01|PriceId=00505681-B634-1EEB-BFA4-0E9DDEB93833|STORE=T000|ACTDATE=20.08.2021";
							
							that.getView().getModel("fotos").create("/FileSet", oEntry, {
									headers: {
										slug: vSlug
									},
									success: function(oData){
											console.log(oData)
									},
									error: function(oError){
										console.log(oError)
									}
								}); 
					}};
				})(this.oContentUpload);
				
				this.oContentUpload.oReader.readAsDataURL(this.oContentUpload);
			}

		});
	});
